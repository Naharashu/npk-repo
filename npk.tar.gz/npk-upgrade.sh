#!/bin/bash
DIR="$HOME/npk"
REPO="https://raw.githubusercontent.com/Naharashu/npk-repo/main/main"
mkdir -p "$DIR/temp/npk"
wget -nv -O "$DIR/temp/npk.tar.gz" "$REPO/npk.tar.gz"
tar -xzf "$DIR/temp/npk.tar.gz" -C "$DIR/temp/npk"
cat "$DIR/info.txt" > "$DIR/npk.update.temp"
source "$DIR/npk.update.temp"
OLD_VER=$VER;
source "$DIR/temp/npk/info.txt"
if [ "$VER" = "$OLD_VER" ]; then
   echo "Nowa Package Keeper is up to date!"
   exit 0
else
    mkdir -p "$DIR/old/npk_$OLD_VER"
    mv "$DIR/npk.sh" "$DIR/old/npk_$OLD_VER/"
    cp -rf "$DIR/temp/npk/." "$DIR/"
    rm -rf "$DIR/temp/npk"
    rm -rf "$DIR/temp/npk.tar.gz"
    rm -rf "$DIR/"*.update.temp
    echo "NPK updated from $OLD_VER to $VER"
    	if [ "$DEP" != "none" ]; then
        	for dep in $DEP; do
            	"$0" -s "$dep"
            done
        fi
fi
exit 0
