#!/bin/bash
OPTION="$1"
DIR="$HOME/npk"
REPO=$(cat "$DIR/repo.txt")
SEEN="${SEEN:-}"

mkdir -p "$HOME/npk"
touch "$DIR/list.txt"

if [ "$OPTION" = "-i" ]; then
	if [ -d "$DIR/$2" ]; then
		"$0" -s "$2"
		exit 0
	fi
	for i in $SEEN; do
		if [ "$i" = "$2" ]; then
			echo "Error: found loop: A->B->A in dependencys"
			exit 1
		fi
	done
	mkdir -p "$DIR/$2"
	for R in $REPO; do
		if wget -nv -O "$DIR/$2/$2.tar.gz" "$R/$2.tar.gz"; then
			break
		fi
	done	
	tar -xzf "$DIR/$2/$2.tar.gz" -C "$HOME/npk/$2"
	source "$DIR/$2/pkg.info.txt"
	if [[ $ARCH != "$(uname -m)" && $ARCH != "any" ]]; then
		echo "Error: uncompetable architectures, your pc not on $ARCH"
		exit 1
	fi
	echo "installed $NAME of version $VER"
	echo "$2" >> "$DIR/list.txt"
	SEEN="$SEEN $2"
	export SEEN
	if [ "$DEP" != "none" ]; then
		for dep in $DEP; do
			"$0" -i "$dep"
			echo "Installed dependency $dep for package $2"
		done
	fi
fi

if [ "$OPTION" = "-s" ]; then
	if [ -d "$DIR/$2" ]; then
		:
	else
		echo "Package $2 doesnt installed, use npk -i $2 to install it"
		exit 0
	fi
	mkdir -p "$DIR/temp/$2"
	for R in $REPO; do
		if wget -nv -O "$DIR/temp/$2.tar.gz" "$R/$2.tar.gz"; then
			break
		fi
	done
	tar -xzf "$DIR/temp/$2.tar.gz" -C "$DIR/temp/$2"
	cat "$DIR/$2/pkg.info.txt" > "$DIR/$2.update.temp"
	source "$DIR/$2.update.temp"
	OLD_VER=$VER;
	source "$DIR/temp/$2/pkg.info.txt"
	if [ "$VER" = "$OLD_VER" ]; then
		echo "There is nothing to update!"
		exit 0
	else
		mkdir -p "$DIR/old/$2_$OLD_VER"
		mv "$DIR/$2/"* "$DIR/old/$2_$OLD_VER/"
		mv "$DIR/temp/$2/"* "$DIR/$2/"
		rm -rf "$DIR/temp/$2"
		rm -rf "$DIR/temp/$2.tar.gz"
		rm -rf "$DIR/"*.update.temp
		echo "$2 updated from $OLD_VER to $VER"
		if [ "$DEP" != "none" ]; then
				for dep in $DEP; do
					"$0" -s "$dep"
				done
		fi
	fi
fi

if [ "$OPTION" = "-u" ]; then
	"$DIR/npk-upgrade.sh"
fi

if [ "$OPTION" = "-l" ]; then
	cat "$DIR/list.txt"
fi

if [ "$OPTION" = "-r" ]; then
	if [ -d "$DIR/$2" ]; then
		:
	else
		echo "Package $2 doesnt exist!"
		exit 0
	fi

	echo "Package $2 will be deleted, do you want to do it?(y/n)"
	read delete_pkg
	if [[ "$delete_pkg" = "y" || "$delete_pkg" = "Y" ]]; then
		rm -rf "$DIR/$2"
		sed -i "/^$2$/d" "$DIR/list.txt"
		echo "Package $2 removed"
	else
		echo "Canceled"
	fi
fi

if [ "$OPTION" = "-v" ]; then
	echo "Nowa Package Keeper (MIT License)"
	echo "Current version:             1.2 "
	echo "Repo1: https://cdn.jsdelivr.net/gh/Naharashu/npk-repo@main/main/"
	echo "Repo2: https://cdn.jsdelivr.net/gh/Naharashu/npk-repo@main/extra/"
	exit 0
fi

if [ "$OPTION" = "-cleanup" ]; then
	echo "Temp and old folder will be deleted, do you want to do it?(y/n)"
		read delete_pkg
		if [[ "$delete_pkg" = "y" || "$delete_pkg" = "Y" ]]; then
			rm -rf "$DIR/"*.update.temp
			rm -rf "$DIR/temp/"*
			rm -rf "$DIR/old/"*
			echo "Done"
		else
			echo "Canceled"
	fi
fi
